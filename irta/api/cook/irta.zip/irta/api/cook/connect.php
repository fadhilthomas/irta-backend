<?php
$server		= "156.67.208.8";
$username	= "tenesysx_irta";
$password	= "tukanglomba";
$database 	= "tenesysx_irta";
$mysqli = mysqli_connect($server,$username,$password,$database) or die("Koneksi gagal");
?>