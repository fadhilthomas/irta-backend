<?php

/**
 * Exception
 * @author Nikita Gusakov <dev@nkt.me>
 */
class TException extends \Exception
{
}